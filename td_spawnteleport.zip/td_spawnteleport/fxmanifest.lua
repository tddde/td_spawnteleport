fx_version 'cerulean'
game 'gta5'

author 'tddd'
description 'Scripts that teleports you to coords when you join the server'
version '1.0.0'

lua54 'yes'

client_script 'client/main.lua'

server_script 'server/main.lua'

shared_script 'config.lua'

escrow_ignore 'config.lua'
