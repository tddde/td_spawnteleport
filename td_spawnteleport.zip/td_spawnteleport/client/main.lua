RegisterNetEvent('TDSpawnTeleport:TeleportToSpawn')
AddEventHandler('TDSpawnTeleport:TeleportToSpawn', function()
    local spawnCoords = Config.SpawnCoords

    SetEntityCoords(PlayerPedId(), spawnCoords.x, spawnCoords.y, spawnCoords.z, 0, 0, 0, false)
    
    if spawnCoords.heading then
        SetEntityHeading(PlayerPedId(), spawnCoords.heading)
    end
    
    DoScreenFadeIn(1000)
end)

AddEventHandler('playerSpawned', function()
    TriggerServerEvent('TDSpawnTeleport:PlayerJoined')
end)
