RegisterServerEvent('TDSpawnTeleport:PlayerJoined')
AddEventHandler('TDSpawnTeleport:PlayerJoined', function()
    local _source = source
    TriggerClientEvent('TDSpawnTeleport:TeleportToSpawn', _source)
end)
