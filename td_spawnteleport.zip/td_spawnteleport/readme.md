TD SPAWN TELEPORT

Simple script that teleports players to coords when they join the server.
Easy configuration in Config.lua.
Fully customizable since its OpenSourced.

For support contact me on discord or join my discord server

https://discord.gg/TmbMN6b4Mq

@tddd__