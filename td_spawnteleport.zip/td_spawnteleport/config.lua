Config = {}

-- Set the spawn coordinates here
Config.SpawnCoords = {
    x = -1342.3134,
    y = 58.4758,
    z = 55.2456,
    heading = 0  -- Optional, if you dont need this it can stay on 0
}
